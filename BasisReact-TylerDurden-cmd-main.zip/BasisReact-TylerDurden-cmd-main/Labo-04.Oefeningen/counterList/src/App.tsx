import React ,{useEffect, useState} from 'react';

const ButtonList = () => {

  const [counters, Setcounters] = useState<number[]>([])
  const [num , SetNum] = useState(0);

  useEffect(()=>{

  const count = () => {
    Setcounters([...counters, num])
  }
  count();
}, [])

const CountUp = () => {
  SetNum((counters)=> counters + 1);
}
const CountDown = () => {
  SetNum((counters)=> counters - 1);
}

  return (
    <React.Fragment>

    <button onClick={CountDown}>Omlaag</button>

    <p>Count: {num} </p>

    <button onClick={CountUp}>Omhoog</button>

    <button onClick={Setcounters}>Add Counter</button>

    </React.Fragment>
  )
}


const App = () => {



  return (
    <React.Fragment>
    <ButtonList />
    </React.Fragment>
  )
}

export default App; 
