import React, { useEffect, useState } from 'react';

interface SlotsProp {
  num:number
}

const Slots = (prop:SlotsProp) => {

  const ArrayOfSlots:string[] = ["https://similonap.github.io/webframeworks-cursus/assets/images/slot-cherry-cce8464b32439efb4f79fba017477125.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-lemon-52cd7112e8b6d398f97e69f8ce2da623.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-melon-593489676a762d464eaea97127970d28.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-prune-e486170eb7c22e6e9aed5de0316b5209.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-seven-e71e0d10655b5491197925624b5ac139.png"
]
let RndNumber;
const SlotsAr:string[] = [];
const For = (AmountOfSlots:number) =>{
  for(let i = 0; i < AmountOfSlots; i++){
    RndNumber = Math.round(Math.random() * 4)
    SlotsAr[i] = ArrayOfSlots[RndNumber]
  }
  return SlotsAr
}

const [slots, Setslots] = useState<string[]>(For(prop.num))
const [money, Setmoney] = useState(102);
const [trueFalls, SettrueFalls] = useState<boolean>(false);



useEffect(()=>{
  SettrueFalls(false)
  if(slots.every((slot) => slot == slots[0])){
    SettrueFalls(true);
  }else{
    false
  }

const MoneyFunction = () => {
  if(trueFalls == true){
    Setmoney((num)=> num + 20)
  }else{
    Setmoney((num)=> num - 1)
  }
}
MoneyFunction();
}, [slots])


const ClickChange = () => {
  Setslots(For(prop.num));
}

  return (
    <>
    {slots.map((e)=>
    <img src={e} width={40}/>
    )}
    <p>{money}</p>
    <button onClick={ClickChange}>Pull lever</button>
    </>
  )
}




const App = () => {return (
  <>
  <Slots num={5}/>
  <Slots num={5}/>
  </>
)};



export default App;