import React from "react";
import {useState} from "react";


interface Students{
  name:string,
  age:number,
  year:number
}


const Filtering = (prop:Students) =>{
  const StudentsList:Students[] = [
    {
    name: "joachim",
    age: 20, 
    year: 2,
    },
    {
      name: "Jan",
      age:20, 
      year:1
    },
    {
      name:"Joris",
      age: 22,
      year: 3

    },
    {
      name: "Piet",
      age: 21,
      year: 2
    }
    
  ]


  return (
    <React.Fragment>
      <input type="text"></input>
    </React.Fragment>
  )

}

const App = () => {
  return (
    <React.Fragment><Filtering/></React.Fragment>

  )
};


export default App;
