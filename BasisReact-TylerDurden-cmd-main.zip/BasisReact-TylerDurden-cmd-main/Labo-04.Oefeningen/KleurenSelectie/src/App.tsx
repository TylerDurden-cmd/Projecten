import React, { useState } from "react";

const ColorSelect = () => {

  const [selectedcolors, Setselectedcolors] = useState<string[]>();


  return (
    <React.Fragment>
      <select name="" id="" value= {selectedcolors} onChange={((e)=>Setselectedcolors(e.target.value))}>
        <option value="red">red</option>
        <option value="green">green</option>
        <option value="blue">blue</option>
        <option value="yellow">yellow</option>
        <option value="orange">orange</option>
        <option value="white">white</option>
        <option value="purple">purple</option>
        <option value="black">black</option>
        </select>   

        <button>Select color</button>
    </React.Fragment>
  )
};

const App = () => {

  return (
    <React.Fragment>
<ColorSelect/>
    </React.Fragment>
  )
};

export default App; 
