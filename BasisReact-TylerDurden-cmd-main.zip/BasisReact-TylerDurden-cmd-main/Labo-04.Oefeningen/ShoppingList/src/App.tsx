import React from "react";
import { useState } from "react";

const ShoppingList = () => {

  interface shoppinglist{
    num:number,
    name:string
  }

  const [shoppinglist, SetShoppinglist] = useState<shoppinglist[]>([]);
  const [nameProduct, SetnameProduct] = useState<string>("");
  const [quantity, SetQuantity] = useState<number>(0);


  
  const NewItem:shoppinglist = {
    num: quantity,
    name:nameProduct
  }

  const AddClicked = () => {

    SetShoppinglist([...shoppinglist, NewItem])


  }

  const DeleteObject = (i:number) => {
    const numberRemove = shoppinglist.filter((item, index)=>index !== i);
    SetShoppinglist(numberRemove)
  }

  return (
    <React.Fragment>
      
        <label htmlFor="Name">Name:</label>
        <input type="text" onChange={((e)=>SetnameProduct(e.target.value))} value={nameProduct}/>
        <label htmlFor="Quantity">Quantity:</label>
        <input type="number" onChange={((e)=>SetQuantity(parseInt(e.target.value)))} value={quantity}/>
        <button onClick={AddClicked}>Add</button>
      

<table>
  <thead>
    <tr>
      <th>
        Name
      </th>
      <th>
        Quantity
      </th>
    </tr>
  </thead>
  <tbody>
    {shoppinglist?.map((event, index)=>
    (<tr key={index}>
      <th>
        {event.name}
      </th>
      <th>
      {event.num}
      </th>
      <td><button onClick={()=>{DeleteObject(index); }}>x</button></td>
    </tr>)
    )}
  </tbody>
</table>

    </React.Fragment>
  )
}

const App = () => {
  return (
    <React.Fragment>
      <ShoppingList/>
    </React.Fragment>
  )
};


export default App;

