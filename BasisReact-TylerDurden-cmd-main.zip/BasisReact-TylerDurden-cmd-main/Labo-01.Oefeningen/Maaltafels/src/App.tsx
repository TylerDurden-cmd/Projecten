import './App.css'

function App() {

  const numbers:number[] = [];
  for(let i = 1; i < 11 ; i++){
    for(let j = 1; j <= 10; j++){
      numbers.push(i* j);
    }
  }
  
  return (
    <>
    <div>
    <table> 
      {numbers.map(()=> 
      <tr>
        {numbers.map((n)=>
        <td>
          {n}
        </td>
        )}
      </tr>
      )}
    </table>
    </div>
    </>
  )
}

export default App
