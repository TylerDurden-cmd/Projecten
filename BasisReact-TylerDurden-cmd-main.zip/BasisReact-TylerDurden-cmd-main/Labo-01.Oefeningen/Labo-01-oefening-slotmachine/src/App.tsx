import React from 'react'
import './App.css'

function App() {

  const ArrayOfSlots:string[] = ["https://similonap.github.io/webframeworks-cursus/assets/images/slot-cherry-cce8464b32439efb4f79fba017477125.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-lemon-52cd7112e8b6d398f97e69f8ce2da623.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-melon-593489676a762d464eaea97127970d28.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-prune-e486170eb7c22e6e9aed5de0316b5209.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-seven-e71e0d10655b5491197925624b5ac139.png"
]
const slot1:number = Math.round(Math.random() * 4);
    const slot2:number = Math.round(Math.random() * 4);
    const slot3:number = Math.round(Math.random() * 4);
  const slotMachine = () =>{
  
    const trueOrfalse:boolean = slot1 == slot2 && slot2 == slot3;
  
    if(trueOrfalse == true){
      return <p>je hebt gewonnen</p>
    }else{
      return <p>je hebt verloren</p>
    }
  
  };

  const buttonRefresh = () =>{
    return window.location.reload();
  }
  
  

  return (
    <React.Fragment>
      <h3>Labo 01: oefening slot machines</h3>
      <img src="https://similonap.github.io/webframeworks-cursus/assets/images/slot-cherry-cce8464b32439efb4f79fba017477125.png" alt="kers" height={50}/>
      <img src="https://similonap.github.io/webframeworks-cursus/assets/images/slot-lemon-52cd7112e8b6d398f97e69f8ce2da623.png" alt="limoen" height={50}/>
      <img src="https://similonap.github.io/webframeworks-cursus/assets/images/slot-melon-593489676a762d464eaea97127970d28.png" alt="meloen" height={50}/>
      <img src="https://similonap.github.io/webframeworks-cursus/assets/images/slot-prune-e486170eb7c22e6e9aed5de0316b5209.png" alt="druif" height={50}/>
      <img src="https://similonap.github.io/webframeworks-cursus/assets/images/slot-seven-e71e0d10655b5491197925624b5ac139.png" alt="zeven" height={50}/>
      {slotMachine()}

      <img src={ArrayOfSlots[slot1]} height={50} />
      <img src={ArrayOfSlots[slot2]} height={50}/>
      <img src={ArrayOfSlots[slot3]} height={50}/>

      <br></br>
      <button  id='btn' onClick={buttonRefresh}>refresh</button>
    </React.Fragment>
  )
}

export default App
