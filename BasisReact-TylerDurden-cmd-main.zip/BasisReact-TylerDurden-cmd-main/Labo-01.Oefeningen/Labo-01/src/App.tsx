
import React from 'react';
import './App.css'

const App = () => {
  const random = Math.random();
  const getal1 = Math.round(Math.random() * 10);
  const getal2 = Math.round(Math.random() * 10);
  const Param:number[] = [10,4];
  
const sum = (a:number, b:number) =>{
  return a + b;
}

const divide = (a:number, b:number) =>{
  return (a / b);
}

const numberOfSum:number = sum(Param[0],Param[1]);
const numberOfDivination:number = divide(Param[0],Param[1]);

const Rendering = (rnd:number, numberOfSum:number, numberOfDivination:number) =>{
if(rnd < 0.5){
  return <h3>the number is  {numberOfSum} </h3>
}else{
  return <h3>the number is {numberOfDivination} </h3>
}
}

  return (
      <React.Fragment>
          <h1>Labo 1</h1>
          <h3>Your random number: {random}</h3>
          <h3>Two other numbers: {getal1},{getal2}</h3>
          {/* <h3>the sum of the numbers {Param[0]} en {Param[1]}is : {sum(Param[0],Param[1])} </h3> */}
          {/* <h3>the divided number of the numbers {Param[0]} en {Param[1]}is : {divide(Param[0],Param[1])} </h3> */}
          <h3> {Rendering(random, numberOfSum, numberOfDivination)} </h3>

          <div>
            {random > 0.5 ? <p>We hebben geluk gehad</p> : <p>Geen geluk gehad</p>}
          </div>
          <div>
            {random > 0.5 && <p>We hebben geluk gehad</p> }{/* heeft geen else nodig */}
          </div>
      </React.Fragment>
  );
}


export default App;
