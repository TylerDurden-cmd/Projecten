import React from 'react'
import './App.css'

function App() {


  interface Students{
    Name:string,
    Age:number
    id:number
  }

  const num:number[] = [1,2,3,4,4,2,12,2];

  const StudentObject:Students[] = [
  {Name:'Joachim', Age:20, id:0}, 
  {Name:'Ziva', Age: 18, id:1} , 
  {Name:"Ivan", Age:21, id:2}
];
const StudentsWithJ = StudentObject.filter((Stu:Students)=> Stu.Name.startsWith("J"));



  return (
      <React.Fragment >
        <h3>Getallenlijst:</h3>
        <ul>
          {num.map((num:number)=>
          <li>
            {num}
          </li>
          )}
        </ul>

        <h3>
          StudentenLijst:
        </h3>
        <ol>
        {StudentObject.map((Stu:Students) => 
        <li key={Stu.id}>
          {Stu.Name}
        </li>
        )}
        </ol>
        <h3>Students J</h3>
        <ol>
        {StudentsWithJ.map((StuJ:Students) =>
          <li key={StuJ.id}>
            {StuJ.Name}
          </li>
        )}

        </ol>

        <h3>Select</h3>
        <select>
          {StudentObject.map((StuSelect:Students)=>
          <option key={StuSelect.id}>
            {StuSelect.Name}
          </option>
          )}
        </select>

        <h3>
          Table
        </h3>

        <table>
          <thead>
            <tr>
              <th>Naam</th>
              <th>Leeftijd</th>
            </tr>
          </thead>
          <tbody>
            {StudentObject.map((StuTable:Students)=>
            <tr>
              <th>{StuTable.Name}</th>
              <th>{StuTable.Age}</th>
            </tr>
            )}
          </tbody>
        </table>
      </React.Fragment> 
)
    
  
}


/* function App() {
  interface Numbers {
    getal:number
    id:number
  }

  interface Students{
   id:number,
   Name:string,
   Age:number 
  }

  const Student:Students[] = [{id:0,Name:"joachim",Age:20},{id:1,Name:"Ivan",Age:20},{id:0,Name:"Ziva", Age:18}]

const DifferentNumbers:Numbers[] = [{getal: 2,
  id: 0},{
    getal:3,
    id:1
  },{
    getal:2,
    id:2
  },{
    getal:5,
    id:3
  }
  ]

  

  return (
    DifferentNumbers.map((Num:Numbers) =>
      <React.Fragment key={Num.id} >
        <li>
          {Num.getal}


        </li>
      </React.Fragment>

    )
  )
}
 */
export default App
