import React from 'react'
import './App.css'

function App() {

  const Alpa:string[] = ["a","b","c","d","e","f","g","h","i","j","k","l",
  "m","n","o","p","q","r","s","t","u","v","w","x","y","z"];

  const images:string[] =[]
  for(let i = 0; i < Alpa.length; i++){
    images[i] = `https://raw.githubusercontent.com/slimmii/alien-alphabet/master/${Alpa[i].toUpperCase()}.png`
  }
  return (
    <React.Fragment>
      <h3>Alien Alphabet: </h3>
      {images.map((I:string)=>
      <button>
        <img src={I}></img>
      </button>
      )}
    </React.Fragment>
  )
}

export default App
