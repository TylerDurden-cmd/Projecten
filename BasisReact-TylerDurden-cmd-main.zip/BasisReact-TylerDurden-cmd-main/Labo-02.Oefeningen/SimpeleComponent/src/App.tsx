import React from "react";

// Interfaces Here:
interface HeaderProps{
  title:string,
  SubTitle:string
}

interface ListProps{
  text?:string
  Items?:string[]
}

interface FooterProps{
  name:string,
  year:number
}

const ArrayItems:string[] = ["Item1", "Item2", "Item3"];

const Header = (prop:HeaderProps)=>{
  return (
  <>
  <h1>{prop.title}</h1>
  <h3>{prop.SubTitle}</h3>
  </> 
  )
}

const ListItem = (prop:ListProps) =>{
  return prop.text;
}

const List = (prop:ListProps) =>{
  return (
    <>
    {prop.Items?.map((item)=> <li><ListItem text={item}/></li>)}
    </>
 )

}

const Footer = (prop:FooterProps) =>{
  return (
    <>
    <footer>
      <p>&copy; {prop.name} {"("}{prop.year}{")"} </p>
    </footer>
    </>
  )
}

const App = () =>{
  
  return (
    <React.Fragment>
      <Header title="Labo02" SubTitle="Basic Component"/>
      <ul>
      <List Items={ArrayItems}/>
      <Footer name="Adomako Joachim" year={2023}/>
      </ul>
    </React.Fragment>
  )
}

export default App;