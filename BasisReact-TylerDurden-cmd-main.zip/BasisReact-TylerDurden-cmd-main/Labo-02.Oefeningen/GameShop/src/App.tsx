//hide-start
import React from "react";

interface Game {
  id: number
  name: string,
  releaseYear: number,
  sales: number
}

interface ListProps {
    games: Game[]
}
//hide-end
interface ListItemProps {
  game: Game
}

const ListItem = ({game} : ListItemProps) => {
    return (
        <React.Fragment>
            <h2>{game.name} ({game.releaseYear})</h2>
            <p>Aantal keer verkocht: {game.sales}</p>
        </React.Fragment>
    )
}

const List = ({games}: ListProps) => {
  return (
    <div>
    {games.map((game: Game) => {
        return <ListItem key={game.id} game={game}/>
      })}
    </div>
  );
}
//hide-start
const App = () => {
  const games : Game[] = [
    {
        id: 0,
        name: "World of Warcraft",
        releaseYear: 2004,
        sales: 5
    },
    {
        id: 1,
        name: "Valheim",
        releaseYear: 2021,
        sales: 10
    },
    {
        id: 2,
        name: "Minecraft",
        releaseYear: 2011,
        sales: 20
    }
  ];
  return (
    <div>
      <h1>Welcome to the H2O Game shop</h1>
      <List games={games}/>
    </div>
  );
}
export default App;
//hide-end