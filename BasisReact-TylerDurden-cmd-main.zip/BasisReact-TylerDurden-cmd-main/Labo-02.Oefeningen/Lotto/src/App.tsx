import React from 'react'
import './App.css'


interface SlotMachineProperty{
  slots:number
}

const SlotMachine = ({slots}:SlotMachineProperty) =>{


  const ArrayOfSlots:string[] = ["https://similonap.github.io/webframeworks-cursus/assets/images/slot-cherry-cce8464b32439efb4f79fba017477125.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-lemon-52cd7112e8b6d398f97e69f8ce2da623.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-melon-593489676a762d464eaea97127970d28.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-prune-e486170eb7c22e6e9aed5de0316b5209.png",
  "https://similonap.github.io/webframeworks-cursus/assets/images/slot-seven-e71e0d10655b5491197925624b5ac139.png"
]

const SlotArray:number[] = [];
    for(let i = 0; i < slots; i++){
      
      const SlotNumber = Math.round(Math.random() * 4);
      SlotArray.push(SlotNumber)
    }

      

  const slotMachine = () =>{
    const trueOrfalse:boolean = SlotArray.every((element)=> element == SlotArray[0]);
  
    if(trueOrfalse == true){
      return <p>je hebt gewonnen</p>
    }else{
      return <p>je hebt verloren</p>
    }
  
  };
const SlotsArrayLooper = [];
  for(let i = 0; i < slots; i++){
    SlotsArrayLooper.push(ArrayOfSlots[SlotArray[i]]);
  }

  return (
    <React.Fragment>
      {SlotsArrayLooper.map((slot)=>
      <img src={slot} height="50"></img>
      )}
      {slotMachine()}
  </React.Fragment>
  )

}



function App() {


  const buttonRefresh = () =>{
    return window.location.reload();
  }
  
  

  return (
    <React.Fragment>
      <h3>Labo 02: oefening slot machines</h3>
{/* StartFunction */}
      <SlotMachine slots={5}/>
      <SlotMachine slots={4}/>
      <SlotMachine slots={3}/>
{/* End */}
      <br></br>
      <button  id='btn' onClick={buttonRefresh}>refresh</button>
    </React.Fragment>
  )
}

export default App
