import { useParams,  Outlet, createBrowserRouter, RouterProvider, Route, NavLink,Link } from "react-router-dom";
import "./App.css";
//hide-start
const Root = () => {
    return (
        <div className="container">
            <div className="head">Header</div>
            <div className="nav">
                <NavLink className={({isActive}) => isActive ? "activeNavLink" : "navLink"} to="/" >Home</NavLink>
            </div>
            <div className="content">
                <Outlet/>
            </div>
            <div className="footer">
                Footer
            </div>
        </div>
    );
}
//hide-end
const Home = () => {
    return (
        <div>
            <ul>
                <li><Link to="/detail/1">Detail 1</Link></li>
                <li><Link to="/detail/2">Detail 2</Link></li>
                <li><Link to="/detail/3">Detail 3</Link></li>
            </ul>
        </div>
    );
}

const Detail = () => {
    let { id } = useParams();

    return (
        <div>Detail {id}</div>
    );
}


const App = () => {
    const router = createBrowserRouter([
        {
            path: "/",
            element: <Root/>,
            children: [
                {
                    path: "",
                    element: <Home/>
                },
                {
                    path: "detail/:id",
                    element: <Detail/>
                }
            ]
        }
    ]);

    return (
        <div>
            <RouterProvider router={router} />
        </div>
    )
}

export default App; 