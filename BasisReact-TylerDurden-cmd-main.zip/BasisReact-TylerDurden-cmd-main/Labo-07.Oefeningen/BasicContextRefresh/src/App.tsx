import React from "react";
import { useState } from "react";
import { SettingsContext } from "./SettingsContext";
import SelectionBox from './SelectionBox';
import SquareRow from "./SquareRow";


const App = () => {

  const [color, setColor] = useState("red")

  return (
    <>
    <SettingsContext.Provider value={{color:color, setColor:setColor}}>
    <SelectionBox/>
    <SquareRow/>
    </SettingsContext.Provider>
    </>
  )
}

export default App;