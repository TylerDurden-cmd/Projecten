import { useContext } from "react";
import { SettingsContext } from "./SettingsContext";

const Square = () => {

    const {color,setColor} = useContext(SettingsContext)


    
    const ChangeColor = () => {
        if(color == "red"){
            setColor('green')
        }else if(color == 'green'){
            setColor('blue')
        }else if(color == 'blue'){
            setColor('red')
        }
    }

    return (
        <>
        <div onClick={ChangeColor} style={{backgroundColor: `${color}` , width: 100, height: 100, margin: 10}}>

        </div>
        </>
    )
}

export default Square;