import { createContext } from "react";
import React from "react";

export interface SettingsProp {
    color:string;
    setColor:(color:string) => void;
}

export const SettingsContext = React.createContext<SettingsProp>({color:'red', setColor:() => {}});