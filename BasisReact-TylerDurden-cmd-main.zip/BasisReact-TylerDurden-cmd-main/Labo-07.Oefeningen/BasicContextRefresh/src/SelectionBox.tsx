import { SettingsContext } from "./SettingsContext";
import { useContext } from "react";


const SelectionBox = () => {

    const {color, setColor} = useContext(SettingsContext);
    return (
        <>
        <select value={color} onChange={((e)=>setColor(e.target.value))}>
            <option value="red">red</option>
            <option value="green">green</option>
            <option value="blue">blue</option>
        </select>
        </>
    )
}

export default SelectionBox;