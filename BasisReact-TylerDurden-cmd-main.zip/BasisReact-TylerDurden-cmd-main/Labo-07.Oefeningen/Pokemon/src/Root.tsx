import React from 'react';
import {Outlet} from 'react-router-dom';
import Navigatie from './Navigatie';
import Footer from './Footer'

const Root = () => {
    return (
        <>
        <Navigatie/>
        <Outlet/>
        <Footer/>
        </>
    )
}

export default Root;