import React from "react";
import Pokemon, { PokemonProp } from "./Pokemon";
import PokemonProp from "./Pokemon";
import { useState , useEffect} from "react";
import { useParams } from "react-router-dom";

const IndividualPokemon = (pokemon:PokemonProp) => {

    let {id} = useParams();
    const [pokemon, setpokemon] = useState<PokemonProp>();
    
    const FetchPokemon = async() => {
        const url = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${150}`)
        const json:PokemonProp = await url.json().then((prom)=>prom);
        setpokemon(json);
    }

    useEffect(()=>{
        FetchPokemon();
    },[])

    return (
        <>
        {pokemon.results[id].name}
        </>
    )
}

export default IndividualPokemon;