import React, { useEffect } from "react";
import { useState } from "react";
import { SettingsContext } from "./SettingsContext";
import { useContext } from "react";
import { Link } from "react-router-dom";

interface PokemonProp {
    results:[{
        name:string;
    }]
}

const Pokemon = () => {

    const [pokemon, setpokemon] = useState<PokemonProp>();
    const {search,setSearch} = useContext(SettingsContext);

    const FetchPokemon = async() => {
        const url = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${150}`)
        const json:PokemonProp = await url.json().then((prom)=>prom);
        setpokemon(json);
    }

    useEffect(()=>{
        FetchPokemon();
    },[])

        const pokemonFilter = pokemon?.results.filter((pokemon) =>
        { return pokemon.name.includes(search)}
        )

    return (
        <>
        <input type="text" onChange={((event)=> setSearch(event.target.value))} value={search}/>
        {pokemonFilter?.map((event,index)=>
        <div key={index}>
            <Link to={`/Pokemon/${index}`}>{event.name}</Link>
        </div>
        )}
        </>
    )

}

export default Pokemon;