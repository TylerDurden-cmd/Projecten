const Home = () => {
    return (
        <>
        <section style={
            {display:'flex', flexWrap:'wrap'}
        }>
            <img src="https://similonap.github.io/webframeworks-cursus/assets/images/oak-7ea4f019fbeb2d928458c78a9e20f34a.png" alt="" width={60}/>
        <div>
        <h2>
            Hello there Welcome to the world of Pokemon!
        </h2>
        <h2>
            My name is Oak! Poeple call me the POKEMON prof!
        </h2>
        <h2>
            This world is inhabited by the creatures called POKEMON!
        </h2>
        <h2>
            For some people, POKEMON are pets. Others use them for fights. Myself... I study POKEMON as a profession
        </h2>
        </div>
        </section>
        </>
    )
}

export default Home;