const Footer = () => {
    return (
        <>
        <div style={{height: 30, backgroundColor: 'black', display:'flex', justifyContent:'center'}}>
            <p>&copy; This is made by Joachim</p>
        </div>
        </>
    )
}

export default Footer;