import React from "react";

interface SettingsProp {
    search:string;
    setSearch:(search:string)=> void;
}

export const SettingsContext = React.createContext<SettingsProp>({search:'', setSearch:()=> {}});