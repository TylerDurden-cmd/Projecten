import React from "react";
import {Link} from 'react-router-dom';

const Navigatie = () => {
    return (
        <>
        <div style={{backgroundColor: '#4fddbf' , paddingTop: 5, paddingBottom: 5,color: "white" , display:'flex', gap: 10}}>
            <div>
                <Link to={""}>Home</Link>
            </div>
            <div>
                <Link to={"/Pokemon"}>Pokemon</Link>
            </div>
        </div>
        </>
    )
}

export default Navigatie;
