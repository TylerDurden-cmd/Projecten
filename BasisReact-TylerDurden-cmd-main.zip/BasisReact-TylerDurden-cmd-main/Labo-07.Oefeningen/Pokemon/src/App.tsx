import React, { useState } from 'react'
import {createBrowserRouter, RouterProvider} from "react-router-dom";
import Root from './Root';
import Home from './Home';
import Pokemon from './Pokemon';
import { SettingsContext } from './SettingsContext';
import './App.css'

const App = () => {

  const [search,setSearch] = useState("");

  const router = createBrowserRouter([
    {
      path:'/',
      element:<Root/>,
      children:[
        {
          path:"",
          element: <Home/>
        },
        {
          path:"/Pokemon",
          element:<Pokemon/>
        }
      ]
      
    }
  ])
  return (
    <>
    <SettingsContext.Provider value={{search, setSearch}}> 
    <RouterProvider router={router}/>
    </SettingsContext.Provider>
    </>
  )
}

export default App;