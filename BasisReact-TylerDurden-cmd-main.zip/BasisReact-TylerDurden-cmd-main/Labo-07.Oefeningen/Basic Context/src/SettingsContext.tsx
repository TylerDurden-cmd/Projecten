import React from "react";

interface ColorProp {
    color:string;
    Setcolor:(color:string) => void;
}


export const SettingsContext = React.createContext<ColorProp>({color: 'red', Setcolor: () => {} }) 