import React from 'react';
import SquareRow from './SquareRow';
import SelectionBox from './SelectionBox'
import { SettingsContext } from './SettingsContext';

const App = () => {
  return(<>
  <SelectionBox/>
  <SquareRow/>
  </>)
} 

export default App;