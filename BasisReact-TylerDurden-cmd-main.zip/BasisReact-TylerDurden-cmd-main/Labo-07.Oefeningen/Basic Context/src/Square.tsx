import React, { useContext } from "react";
import { SettingsContext } from "./SettingsContext";


const Square = () => {

    const {color} = useContext(SettingsContext);


    return (
        <>
        <div style={{width: 100, height: 100, backgroundColor: `${color}`, margin: 10}}>
        </div>
        </>
    )
}

export default Square;