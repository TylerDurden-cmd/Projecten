import { useContext } from "react";
import { SettingsContext } from "./SettingsContext";

const SelectionBox = () => {

    const {Setcolor, color} = useContext(SettingsContext);

    return (
        <>
        <SettingsContext.Provider value={}></SettingsContext.Provider>
        <select name="" id="" onChange={(e)=> Setcolor(e.target.value)}>
            <option value="red" >red</option>
            <option value="green">green</option>
            <option value="blue">blue</option>
        </select>
        </>
    )
}

export default SelectionBox;