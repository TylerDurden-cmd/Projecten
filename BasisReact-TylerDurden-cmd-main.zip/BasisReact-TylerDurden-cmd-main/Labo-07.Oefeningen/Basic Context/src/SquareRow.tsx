import Square from "./Square";
import React from "react";

const SquareRow = () => {
    return (
        <>
        <div style={
            {display:'flex'}
        }>
        <Square/>
        <Square/>
        <Square/>
        </div>
        </>
    )
}

export default SquareRow;