const Footer = () => {
    return (
        <>
        <div style={{height:30, backgroundColor:"black"}}>

        </div>
        </>
    )
}

export default Footer;