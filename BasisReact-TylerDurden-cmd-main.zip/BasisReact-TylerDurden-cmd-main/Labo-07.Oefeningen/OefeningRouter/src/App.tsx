import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Root from "./Root";
import Introduction from "./Introduction";
import Home from "./Home";

const App = () => {
  const router = createBrowserRouter([
      {
          path: "/",
          element: <Root/>,
          children: [
              {
                  path: "",
                  element: <Home/>
              },
              {
                  path: "/intro",
                  element: <Introduction/>
              }
          ]
      }
  ]);
  return (
    <>
    <div>
    <RouterProvider router={router}/>
    </div>
    </>
  )
}

export default App;