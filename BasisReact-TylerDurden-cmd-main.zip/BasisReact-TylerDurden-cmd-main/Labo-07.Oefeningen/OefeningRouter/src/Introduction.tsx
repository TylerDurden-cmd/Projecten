

const Introduction = () => {
    return (
        <>
        <p>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptate nemo qui debitis nobis animi. Quidem distinctio sed aperiam, repellat sit, at sapiente architecto eum quisquam, nobis ab. Consequuntur, error aliquam!
        </p>
        </>
    )
}

export default Introduction;