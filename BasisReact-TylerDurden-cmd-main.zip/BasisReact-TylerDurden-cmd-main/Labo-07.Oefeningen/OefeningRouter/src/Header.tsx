const Header = () => {
    return (
        <>
        <h1 style={{display:'flex', justifyContent: "center"}}>Header</h1>
        </>
    )
}

export default Header;