import React from "react";


const Home = () => {
    return (
        

        <p>
        hello world
        </p>

        
    )
}

export default Home;