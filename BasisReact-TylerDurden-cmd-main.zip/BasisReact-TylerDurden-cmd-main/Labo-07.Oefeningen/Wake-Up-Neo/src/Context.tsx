import { createContext } from 'react';

interface TextIng {
    text:string;
}

export const textContext = createContext<TextIng>({text: 'The Matrix is real!'});
