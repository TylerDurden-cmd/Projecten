import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Root from "./Root";
import ChatMessages from "./ChatMessages";
import RegenBoog from "./regenBoog";
import AlienMessages from "./AlienMessages";

const App = () => {
  const router = createBrowserRouter([
    {
      path:'',
      element:<Root/>,
      children:[
        {
          path:'/chatMessages',
          element: <ChatMessages/>

        },
        {
          path: '/regenboog',
          element: <RegenBoog/>
        },
        {
          path: '/alienMessages',
          element: <AlienMessages/>
        }
      ]
    }
  ]);

  return (
    <>
    <div>
      <RouterProvider router={router}/>
    </div>
    </>
  )
}

export default App;