
import React from 'react'
import './App.css'

function RegenBoog() {
  const colors = Array.from({length: 100}, (_, i) => `hsl(${i * 360 / 100}, 100%, 50%)`);
  return (
    <React.Fragment>
      {colors.map((col)=> 
      
      <div style={{backgroundColor: col, width: "100%", height: "4px"}}></div>
      )}
    </React.Fragment>
  )
}

export default RegenBoog;
