import React from "react";
import { Link } from "react-router-dom";




const Navigation = () => {
    return (
        <>
        <div style={
            {backgroundColor: 'grey', height:30}
        }>
            <Link to={'/chatMessages'}>ChatMessages </Link>

            <Link to={'/regenboog'}>RegenBoog </Link>

            <Link to={'/alienMessages'}>AlienMessages </Link>
        </div>
        </>
    )
}

export default Navigation;