import React, { useState } from "react";

interface ShoppingListProperty{
    name:string;
    Quantity:number;
}

const ShoppingList = () => {
    const [shoppinglist, Setshoppinglist] = useState<ShoppingListProperty[]>([])
    const [name, Setname] = useState<string>("")
    const [Quantity, SetQuantity] = useState<number>(0)

    const ShoppinglistAdd = () => {

        const NewObject:ShoppingListProperty = {
            name:name,
            Quantity:Quantity
        }
        
        Setshoppinglist([...shoppinglist,NewObject])
    }

    return (
        <React.Fragment>
            <label htmlFor="Name">Name: </label>
            <input type="text" value={name} onChange={((z)=>Setname(z.target.value))}/>
            <label htmlFor="Quantity">Quantity:</label>
            <input type="number" value={Quantity} onChange={((z)=>SetQuantity(parseInt(z.target.value)))}/>
            <button onClick={ShoppinglistAdd}>add</button>

            <div>
                {shoppinglist.map((event,index)=>
                <div key={index}>
                    {event.Quantity}
                    {event.name}
                </div>
                )}
            </div>
        </React.Fragment>
    )
}

export default ShoppingList;