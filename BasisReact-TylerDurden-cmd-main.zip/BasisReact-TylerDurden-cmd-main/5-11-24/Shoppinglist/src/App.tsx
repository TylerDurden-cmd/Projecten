import React from "react";
import ShoppingList from "./ShoppingList";

const App = () => {

  return (
    <React.Fragment>
      <ShoppingList/>
    </React.Fragment>
  )
}

export default App;