import React from "react";
interface colorProp {
    color:string[];
    setColor:(color:string)=>void;
}

export const ContextColorData = React.createContext<colorProp>({color:[], setColor:()=>{}})