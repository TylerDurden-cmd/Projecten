import React, { useState } from "react";
import ColorSelect from "./ColorSelect";
import { ContextColorData } from "./SettingsContext";

const App = () => {

    const [color, setColor] = useState([])
    
    return (


        <React.Fragment>
            <ColorSelect/>
        </React.Fragment>
    )
}

export default App;