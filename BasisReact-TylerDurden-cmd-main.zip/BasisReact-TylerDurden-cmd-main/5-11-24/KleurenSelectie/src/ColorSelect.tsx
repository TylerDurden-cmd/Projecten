import { ContextColorData } from "./SettingsContext";
import React, { useContext } from "react";

const ColorSelect = () => {

    const {color, setColor} = useContext(ContextColorData);

    const onChange : React.ChangeEventHandler<HTMLSelectElement> = (e) => {
        let selectedOptions:string[] = [];

        for(let option of Array.from(e.target.selectedOptions)){
            selectedOptions.push(option.value)
        }
        setColor(selectedOptions)
    }

    return (
        <React.Fragment>
            <select multiple onChange={onChange}>
                <option value="red">red</option>
                <option value="green">green</option>
                <option value="blue">blue</option>
                <option value="yellow">yellow</option>
                <option value="orange">orange</option>
                <option value="purple">purple</option>
                <option value="black">black</option>
                <option value="white">white</option>
            </select>

            {color.map((e)=>
            <div style={{backgroundColor: `${e}`, height: 50 }}>
            </div>
            )}

        </React.Fragment>
    )
}

export default ColorSelect;