import React, { useState } from "react";
import ColorPicker from "./ColorPicker";
import { ColorContext } from "./SettingsContext";

const App = () => {

    const [color, Setcolor] = useState('#000000');

    return (

        <ColorContext.Provider value={{color:color, Setcolor:Setcolor}}>
        <React.Fragment>
            <ColorPicker/>
        </React.Fragment>
        </ColorContext.Provider>

    )
}

export default App