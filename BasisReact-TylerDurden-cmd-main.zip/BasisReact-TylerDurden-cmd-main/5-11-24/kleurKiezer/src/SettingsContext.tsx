import React from "react";

interface ColorProp {
    color:string;
    Setcolor:(color:string)=>void;
}

export const ColorContext = React.createContext<ColorProp>({color:'#000000', Setcolor:() => {}})