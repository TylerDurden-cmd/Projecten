import React, { useState } from "react";
import ContactFormulier from "./ContactFormulier";
import { ContextContactForm } from "./SettingsContext";


const App = () => {


    const [name, Setname] = useState<string>('');
    const [lastname, Setlastname] = useState<string>('');
    const [email, Setemail] = useState<string>('');
    const [message, Setmessage] = useState<string>('');
    const [ConfirmationText, setConfirmationText] = useState<string>('')

    return (
        <ContextContactForm.Provider value={{name: name, Setname:Setname,
        lastname:lastname, Setlastname:Setlastname, email:email, Setemail:Setemail,
        message:message, Setmessage:Setmessage, ConfirmationText:ConfirmationText, setConfirmationText:setConfirmationText}}>
        <React.Fragment>
            <ContactFormulier/>
        </React.Fragment>
        </ContextContactForm.Provider>
    )
}

export default App;