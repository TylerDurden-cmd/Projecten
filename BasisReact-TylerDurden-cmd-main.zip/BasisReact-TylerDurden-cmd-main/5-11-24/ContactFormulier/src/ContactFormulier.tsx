import React, { useContext } from "react";
import { ContextContactForm } from "./SettingsContext";

const ContactFormulier = () => {

    const {name, Setname, lastname, Setlastname, email, Setemail, message, Setmessage, ConfirmationText, setConfirmationText} = useContext(ContextContactForm);

    const ContactFormFunction = () => {
        Setname(name);
        Setlastname(lastname);
        Setemail(email);
        setConfirmationText(`Thanks ${name} ${lastname}! We will contact you at ${email}`)
    }

    return (
        <React.Fragment>
        <section style={{display: 'flex', flexDirection: 'column' , flexWrap: 'wrap'}}>
            <form onSubmit={ContactFormFunction}>
            <label htmlFor="">firstname:</label>
            <input type="text" name="firstname" value={name} onChange={((e)=>Setname(e.target.value))}/>
            <label htmlFor="">lastname:</label>
            <input type="text" name="lastname" value={lastname} onChange={((e)=>Setlastname(e.target.value))}/>
            <label htmlFor="">Email:</label>
            <input type="text" name="email" value={email} onChange={((x)=> Setemail(x.target.value))}/>
            <label htmlFor="">message</label>
            <textarea name="textarea" id="" value={message} onChange={((j)=>Setmessage(j.target.value))}>
            </textarea>
            <button type="submit">Send</button>
            </form> 

            <p>{ConfirmationText}</p>
        </section>
        </React.Fragment>
    )
}

export default ContactFormulier;