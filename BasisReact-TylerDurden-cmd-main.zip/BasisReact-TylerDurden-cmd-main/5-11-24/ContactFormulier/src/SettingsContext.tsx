import React from "react";

interface ContactFormulierProp {
    name:string;
    Setname:(name:string)=>void;
    lastname:string;
    Setlastname:(lastname:string)=>void;
    email:string;
    Setemail:(email:string)=> void;
    message:string;
    Setmessage:(message:string)=>void;
    ConfirmationText:string;
    setConfirmationText:(ConfirmationText:string)=>void;
}

export const ContextContactForm = React.createContext<ContactFormulierProp>({name:'', 
Setname:()=>{}, lastname:'', Setlastname:()=>{}, email:'', Setemail:() => {}, message:'', Setmessage:()=>{}, ConfirmationText:'', 
setConfirmationText:()=>{}});