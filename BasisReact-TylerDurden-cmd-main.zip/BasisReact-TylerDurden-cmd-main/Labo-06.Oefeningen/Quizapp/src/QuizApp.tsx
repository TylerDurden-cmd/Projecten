/* Deze component zal een beetje documentatie bevatten */

/* hier gebeurd onze import state */
import React, { useEffect } from 'react';
/*  */


/* interfaces */
interface ApiQuizApp {
    category:string;
    type:string;
    difficulty:string;
    question:string;
    correct_answer:string;
    incorrect_answer:string[];
}
/*  */


/* Applicatie functie */
const QuizApp = () => {

    useEffect(()=> {

        const url = fetch(`https://opentdb.com/api.php?amount=${10}`).then((prom)=> prom.json()).then((prom)=> prom.results)

    }, [])

    return (
        <>

        </>
    )

}
/*  */



export default QuizApp;
