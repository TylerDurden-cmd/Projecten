import React from 'react';
import QuizApp from './QuizApp';
const App = () => {
  return (
    <>
    <QuizApp/>
    </>
  )
}


export default App;