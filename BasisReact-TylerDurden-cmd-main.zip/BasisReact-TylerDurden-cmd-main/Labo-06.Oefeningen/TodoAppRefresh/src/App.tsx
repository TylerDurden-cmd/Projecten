import React, {useState} from "react";
import ToDoList from "./TodoList";
import ToDoInput from "./ToDoInput";
interface TodoItem { 
    name: string;
    completed: boolean;
}

const App = () => {
    const [todos, setTodos] = useState<TodoItem[]>([]);
    const [todo, setTodo] = useState("");
    const addTodo = (todo: string) => {


        setTodos([...todos, { name: todo, completed: false }]);
        setTodo("");
    };

    const markCompleted = (index: number, completed: boolean) => {
        setTodos(todos.map((todo, i) => i === index ? {...todo, completed: completed} : todo));
    };

    return (
        <div>
            <ToDoInput addTodo={addTodo} todo={todo} setTodo={setTodo} />
              <ToDoList todos={todos} markCompleted={markCompleted}/>                
        </div>
    );

}

export default App;

/* Maak drie nieuwe componenten aan in een aparte map components:
TodoList bevat de lijst van taken

TodoItem bevat een enkele taak

TodoInput bevat het input veld en de knop om een taak toe te voegen 

Verplaats de logica van de App component naar de nieuwe componenten
De state die de Todo's bevat moet in de App component blijven.
Je zal dus moeten gebruik maken van 
props om de state door te geven aan de nieuwe componenten.
Je zal ook gebruik moeten maken van child-to-parent 
communicatie om de state te kunnen updaten.
Zorg dat elk component 
in een aparte file staat.
*/