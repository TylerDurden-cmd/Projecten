import React from "react";
import ToDoItem from "./ToDoItem";
interface TodoItem { 
    name: string;
    completed: boolean;
}

interface TodoListProps {
    todos:TodoItem[];
    markCompleted: (index: number, completed:boolean) => void;
}

const ToDoList = ({todos, markCompleted}:TodoListProps) => {
    return <>{todos.map((todo, index) => (
        <ToDoItem markCompleted={markCompleted} todo={todo} index={index}/>
    ))}</>
}

export default ToDoList;