import React from "react";

interface ToDoInputProp{
    addTodo:(item:string) => void;
    todo:string;
    setTodo:(event:string) => void;
}

const ToDoInput = ({addTodo, todo, setTodo}: ToDoInputProp) => {
    return <>
    <div>
        <input id="todo" type="text" value={todo} onChange={(event) => setTodo(event.target.value)}/>
        <button onClick={() => addTodo(todo)}>Add</button>
    </div></>
}

export default ToDoInput;