interface TodoItem { 
    name: string;
    completed: boolean;
}

interface ToDoItemProp{
    index:number;
    todo:TodoItem ;
    markCompleted:(index:number, completed:boolean) => void; 
}


const ToDoItem =({index, todo, markCompleted}:ToDoItemProp) => {
    return <><div key={index}>
    <input type="checkbox" checked={todo.completed} onChange={(event) => markCompleted(index, event.target.checked)}/>
    <span style={{textDecoration: todo.completed ? "line-through" : "none"}}>{todo.name}</span>
</div></>
}

export default ToDoItem