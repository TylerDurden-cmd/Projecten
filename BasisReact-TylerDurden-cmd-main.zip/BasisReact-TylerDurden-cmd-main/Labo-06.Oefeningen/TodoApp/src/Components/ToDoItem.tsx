import {React, useState}from 'react';

/* interface TodoItem { 
    name: string;
    completed: boolean;
}

interface todoprop {
    SETtodo: (todo:TodoItem[]) => void
} */

const ToDoItem = () => {
    const [todo, setTodo] = useState("");
    setTodo("");
}



export default ToDoItem;