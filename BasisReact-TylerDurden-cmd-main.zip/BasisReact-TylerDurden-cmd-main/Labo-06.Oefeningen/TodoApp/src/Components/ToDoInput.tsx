import React from 'react';

interface todoprop{
    addToDo: (todo:string) => void;
    todo:string;
    setTodo: (waarde:string) => void; 
}


const ToDoInput = ({addToDo, todo, setTodo}:todoprop) => {
    return (
<div>
<input id="todo" type="text" value={todo} onChange={(event) => setTodo(event.target.value)}/>
<button onClick={() => addToDo(todo)}>Add</button>
</div>
    )
}

export default ToDoInput;