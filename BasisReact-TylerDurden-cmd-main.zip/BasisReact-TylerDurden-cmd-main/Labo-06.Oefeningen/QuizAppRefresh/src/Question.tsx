import MultipleChoiceQuestions from "./MultipleChoiceQuestions";
import { QuizAppProps } from "./QuizApp";
import TrueFallsQuestions from "./TrueFallsQuestions";

interface QuestionProp {
    question: QuizAppProps;
}

const Question = ({question}:QuestionProp) => {
    return (
        <>
        <div key={question.index}>
        {question.question}
        {question.type === 'multiple' ? <MultipleChoiceQuestions question={question}/> : <TrueFallsQuestions question={question}/>}
        </div>
        </>
    )
}

export default Question;