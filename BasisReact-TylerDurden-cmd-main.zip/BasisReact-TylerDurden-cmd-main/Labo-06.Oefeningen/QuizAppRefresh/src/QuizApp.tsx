/* This Component will have documentation */

import React, { useEffect, useState } from "react";
import Question from "./Question";

/* Imports  */
export interface QuizAppProps{
    index:number
    category:string;
    type:string;
    difficulty:string;
    question:string;
    correct_answer:string;
    incorrect_answers:string[];
}

/* Main quiz application function */

const QuizApp = () =>{

    /* Usestate  */
    const [Quiz, SetQuiz] = useState<QuizAppProps[]>([]);
    const [load, SetLoading] = useState<boolean>(false);
    /* Variables */
    const AmountLimit = 10;


    /* use effect for fetching api with zero dependencies*/
    useEffect(()=> {
        const fetchApi = async() => {
            SetLoading(true);
            
        setTimeout(()=> {} , 1000);
        const url = await fetch(`https://opentdb.com/api.php?amount=${AmountLimit}`)
        const json:QuizAppProps[] = await url.json().then((prom)=> prom.results);

        SetQuiz(json);
        SetLoading(false);

        }

        fetchApi();
    }, [])

    return (
        <React.Fragment>
            {load && 'Application Loading'}
            {Quiz.map((question)=>
            <Question question={question}/>
            )}
        </React.Fragment>
    )
}

export default QuizApp;