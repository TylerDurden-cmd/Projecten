import { QuizAppProps } from "./QuizApp";

interface MultipleChoiceQuestionsProp {
    question:QuizAppProps;
}

const MultipleChoiceQuestions = ({question}: MultipleChoiceQuestionsProp) => {


    
    const AllAnswersParser = [...question.incorrect_answers,question.correct_answer];
    return (
        <>
        <select>
        {AllAnswersParser.map((event, index)=>
        <option value={event} key={index}>
            {event}
        </option>
        )}
        </select>
        </>
    )
}

export default MultipleChoiceQuestions;