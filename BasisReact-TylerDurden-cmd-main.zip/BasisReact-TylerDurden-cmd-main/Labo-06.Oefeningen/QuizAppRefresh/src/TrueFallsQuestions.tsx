import { QuizAppProps } from "./QuizApp";
import React from "react";

interface TrueFallsQuestionsProp{
    question:QuizAppProps;
}

const TrueFallsQuestions =({question}:TrueFallsQuestionsProp) => {
    
    return (
        <>
        <input type="radio" name="Yes" value={question.incorrect_answers} />
        <input type="radio" name="No" value={question.correct_answer}/>
        </>
    )
}

export default TrueFallsQuestions;