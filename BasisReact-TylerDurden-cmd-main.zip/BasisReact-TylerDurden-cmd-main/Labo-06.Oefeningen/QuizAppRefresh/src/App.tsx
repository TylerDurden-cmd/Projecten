import React from "react";
import QuizApp from "./QuizApp";

const App = () => {
  return (
    <React.Fragment>
    <QuizApp/>
    </React.Fragment>
  )
}

export default App;