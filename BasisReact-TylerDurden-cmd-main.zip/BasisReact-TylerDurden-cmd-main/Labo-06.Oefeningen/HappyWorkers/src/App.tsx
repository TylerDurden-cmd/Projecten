import React from "react";
import HappyWorker from "./HappyWorker";

const App = () => {
  return (
    <React.Fragment>
    <HappyWorker/>
    </React.Fragment>
  )
}

export default App;