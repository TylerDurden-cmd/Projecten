/* Small documentation things that need to be fixed */
import React, { useState } from "react";
import Square from "./Square";


const HappyWorker = () => {
    const [Work, SetWork] = useState<number>(0);
    const [Productivity, SetProductivity] = useState<number>(10);
    const [Clicked, SetClicked] = useState<number>(0);

    /* changes that need to be made are the smiles need to be in this component 
    and they need a function that returns a smiley  */

    /* When the smiley is chosen within the function it returns the smiley 
    and the parameter 'property' is given to the Square component */





    /* Als de clicked state groter of gelijk is aan 10 dan moet
     de productivity state op 0 gezet worden. Dit zorgt ervoor dat de Square component een 😵 toont. Het is dan tijdelijk niet meer mogelijk de work state te verhogen met die Square.
    Na 5 seconden moet de productivity state terug op 1 gezet worden. Dit zorgt ervoor dat de Square component terug een 😐 toont. 
    Ook de clicked state wordt terug op 0 gezet.
 */

    return (
        <React.Fragment>
            <progress value={Work} max={100}></progress>
            <div style={{display:'flex'}}>
            <Square color="red" size={50} SetWork={SetWork} Work={Work} Productivity={Productivity} Clicked={Clicked}/>
            <Square color="green" size={50} SetWork={SetWork} Work={Work} Productivity={Productivity} Clicked={Clicked}/>
            <Square color="blue" size={50} SetWork={SetWork} Work={Work} Productivity={Productivity} Clicked={Clicked}/>
            </div>
        </React.Fragment>
    )
};

export default HappyWorker;