import React from "react";

interface SquareProp{
    color:string;
    size:number;
    SetWork:(React.Dispatch<React.SetStateAction<number>>);
    Work:number;
    Productivity:number; 
    Clicked:number;
}

const Square = ({color, Clicked ,size , SetWork, Work, Productivity}: SquareProp) => {
    
        return ( <> 
        <button onClick={() => SetWork((Prev) => Prev + Productivity)} style={{backgroundColor: `${color}` , width: `${size}px`, height: `${size}px`}}>
            {Work < 100 && <p>😐</p>}
            {Work >= 100 && <p>🥰</p> }
            {Clicked >= 10 && <p>🥴</p>}
        </button>
        </>)
};

export default Square;