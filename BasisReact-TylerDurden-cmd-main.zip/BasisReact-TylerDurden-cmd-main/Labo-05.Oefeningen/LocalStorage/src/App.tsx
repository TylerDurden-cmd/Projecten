import React, { useEffect, useState } from "react";


const Dadjoke = () => {
  
  const [loadJoke, SetloadJoke] = useState<boolean>(false);
  const [dadjoke, SetDadjoke] = useState("");
  const [fav, Setfav] = useState("");
  const [newJoke, Setnewjoke] = useState<number>(0);
  
  useEffect(()=>
  {
    
    SetloadJoke(true);
    
      fetch("https://icanhazdadjoke.com",{ headers: {
        Accept: "application/json",
      }, }).then(response => response.json()).then(response => SetDadjoke(response.joke));
      SetloadJoke(false)
    
  }, [newJoke])

  console.log(dadjoke)

  const setAsFavorite = () => {
    Setfav(dadjoke);
    localStorage.setItem("Favorite", fav);
  }

  return (
    <>
    <p><strong>Random Dad joke: </strong></p>
    {loadJoke && "Loading Joke"}
    <div>{dadjoke}</div>
    <button onClick={setAsFavorite}>Set as favorite</button><button onClick={() => Setnewjoke((event) => event + 1)}>New Joke</button>
    {fav && `favorite: ${fav}`}


    </>
  )
}

const App = () => {
  return (
    <>
    <Dadjoke/>
    </>
  )
}



export default App;