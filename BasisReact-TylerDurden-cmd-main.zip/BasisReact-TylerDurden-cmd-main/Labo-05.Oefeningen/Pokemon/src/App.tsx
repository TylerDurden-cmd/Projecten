import React, { useEffect } from 'react';
import { useState } from 'react';

interface PokedexProp {
  limit:number
}
interface PokemonUrlFetch {
  name:string;
  url:string;    
}


const Pokedex = (prop:PokedexProp) => {

  const [loading, SetLoading] = useState(false);
  const [pokemonlist, Setpokemonlist] = useState<PokemonUrlFetch[]>([]);
  const [pokemonname, Setpokemon] = useState<string>("");
  const [num, Setnum] = useState<number>(0);

  useEffect(()=>{
    SetLoading(true);
    const FetchPokeApi = async() => {
      const url = await fetch("https://pokeapi.co/api/v2/pokemon?limit=" + prop.limit);
      const json = await url.json();
      return Setpokemonlist(json.results);
    }
    FetchPokeApi();
    SetLoading(false);
  
  }, []);

  const PokemonNameList = pokemonlist.filter((pokemon)=>{
    return pokemon.name.includes(pokemonname)
  })

  return (
    <>
    <p>{loading && "loading"}</p>
    <input type="text" value={pokemonname} onChange={((e)=>Setpokemon(e.target.value))}/>
    <ol>
      {PokemonNameList.map((pokemon)=>
      <li>
        {pokemon.name}
      </li>
      )}
    </ol>
    <input type="text" value={num} onChange={((e)=>Setnum(Number(e.target.value)))}/>
    <button>Set Limit</button>
    </>
  )
}

const App = () => {
return (
  <>
  <Pokedex limit={151}/>
  </>
)
}

export default App;