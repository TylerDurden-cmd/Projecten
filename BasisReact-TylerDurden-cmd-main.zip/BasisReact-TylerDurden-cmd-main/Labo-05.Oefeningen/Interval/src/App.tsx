import React, { useEffect } from 'react';
import {useState} from 'react';

interface TimezoneInfo {
  abbreviation: string;
  client_ip: string;
  datetime: Date;
  day_of_week: number;
  day_of_year: number;
  dst: boolean;
  dst_from: Date;
  dst_offset: number;
  dst_until: Date;
  raw_offset: number;
  timezone: string;
  unixtime: number;
  utc_datetime: Date;
  utc_offset: string;
  week_number: number;
}

const Timer = () => {
  const [time, Settime] = useState(0);

  useEffect(()=>{
    let handleUseEffect = setInterval(() => {
      Settime(time => time + 1);
    }, 1000);
    return (()=>{
      clearInterval(handleUseEffect);
    })
    
  },[])

  return (
    <>
    {time}
    </>
  )


}

const CurrentTimeComponent = () =>{

  const [urlTimeZone, SeturlTimeZone] = useState<TimezoneInfo>();

  useEffect(()=>{


    const FetchTimeZone = async() => {
      let url = await fetch("http://worldtimeapi.org/api/timezone/Europe/Brussels");
      let json: TimezoneInfo = await url.json();

      SeturlTimeZone(json)
    }
    setInterval(()=>{
      FetchTimeZone();
    }, 1000)

  }, [])
  return (
    <>
    <p>The current time is: {urlTimeZone?.datetime} </p> 
    </>
  )

}

const RandomValue = () => {
  const [randomNumber, SetrandomNumber] = useState(0);
  useEffect(()=>{
    setInterval(()=>{
      SetrandomNumber(randomNumber => randomNumber = Math.round(Math.random() * 100))
    }, 1000)
  }, [])

  return (
    <>
    <p>
      The random Value between 1 and 100: {randomNumber}
    </p>
    </>
  )
}



const App = () => {
  return (
    <>
    <Timer/>
    <CurrentTimeComponent/>
    <RandomValue/>
    </>
  )
}

export default App;
