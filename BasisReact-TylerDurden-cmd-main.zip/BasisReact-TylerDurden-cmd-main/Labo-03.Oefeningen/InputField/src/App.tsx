import React, { useState } from "react";

const InputField = () =>{
  const [inputField, setInputField] = useState("");

  return (
    <React.Fragment>
      <input type="text" onChange={((e)=>setInputField(e.target.value))} value={inputField}/>
      <input type="text" onChange={((e)=>setInputField(e.target.value))} value={inputField}/>
      <input type="text" onChange={((e)=>setInputField(e.target.value))} value={inputField}/>
      <input type="text" onChange={((e)=>setInputField(e.target.value))} value={inputField}/>
      <input type="text" onChange={((e)=>setInputField(e.target.value))} value={inputField}/>
    </React.Fragment>
  )
};

const App = () =>{
  return (
    <React.Fragment>
      <InputField/>
    </React.Fragment>
  )
};

export default App;