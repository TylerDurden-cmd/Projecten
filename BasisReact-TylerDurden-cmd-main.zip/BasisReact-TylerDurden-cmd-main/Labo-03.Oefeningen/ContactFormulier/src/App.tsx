import React, { useState } from "react";

const ContactForm = () =>{

    const [firstname, Setfirstname] = useState<string>();
    const [lastname, Setlastname] = useState<string>();
    const [email, Setemail] = useState<string>();
    const [message, Setmessage] = useState<string>();
    const [confirmationText, SetconfirmationText] = useState<string>();
    

    const ConfirmMessage = () =>{
        Setfirstname(firstname);
        Setlastname(lastname);
        Setemail(email);
        Setmessage(message);
        SetconfirmationText(`Thanks ${firstname} ${lastname}! We will contact you at ${email}`)
    }

    return(
        <React.Fragment>
            <form onSubmit={ConfirmMessage}>
                <label htmlFor="lastname">Last Name:</label>
                <input type="text" value={firstname} onChange={((e)=>Setfirstname(e.target.value))}/>
                <label htmlFor="firstname">First Name:</label>
                <input type="text" value={lastname} onChange={((e)=>Setlastname(e.target.value))}/>
                <label htmlFor="email">Email:</label>
                <input type="text" value={email} onChange={((e)=>Setemail(e.target.value))}/>
                <textarea name="" id="" value={message} onChange={((e)=>Setmessage(e.target.value))}></textarea>
                <button type={"submit"}></button>
            </form>

            {confirmationText && <div>
                {confirmationText}
                </div>}

        </React.Fragment>
    )
}

const App = () => {

    return(
        <React.Fragment>
     <ContactForm/>       
        </React.Fragment>
    )
}

export default App;