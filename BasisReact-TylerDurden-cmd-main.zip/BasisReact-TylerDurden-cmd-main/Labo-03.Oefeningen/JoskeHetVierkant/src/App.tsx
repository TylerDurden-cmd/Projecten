import React from 'react';
import { useState } from 'react';

const JoskeNaarJosje = () => {
  const [mood, SetMood] = useState<string>(":(")
  const [shape, SetShape] = useState<boolean>()
  const [name, SetName] = useState<string>("");
  const [Givenname, SetGivenname] = useState<string>("joske");

  const Originalname = () => {
    SetName("joske")
    SetGivenname("joske")
  }

  
  const AddClicked = () => {
    SetGivenname(Givenname => Givenname = name)
  }

  return (
    <React.Fragment>
      <div style={{display:'flex', flexWrap: 'wrap', alignItems:'center', flexDirection: 'column'}}>
      <p>{Givenname}</p>
      <div style={{backgroundColor: "red", width: 100, height: 100, borderRadius: shape ? 100 : 30, display:'flex', alignItems: "center", alignContent: 'center', justifyContent: "center"}}>
        <h1>{mood}</h1>
      </div>

      <input type="text" value={name} onChange={((e)=>SetName(e.target.value))}/>
      <button onClick={Originalname}>Reset name</button>
      <button onClick={AddClicked}>Set</button>

      <input type="checkbox" onChange={((event)=>SetShape(event.target.checked))}/>
      
      <select name="" id=""  onChange={((event) => SetMood(event.target.value))} value={mood}>
        <option value=":(">{":("}</option>
        <option value=":|">{":|"}</option>
        <option value=":)">{":)"}</option>
      </select>

      </div>
    </React.Fragment>
  )
}

const App = () =>{

  return (
    <React.Fragment>
      <JoskeNaarJosje/>
    </React.Fragment>
  )
};

export default App; 