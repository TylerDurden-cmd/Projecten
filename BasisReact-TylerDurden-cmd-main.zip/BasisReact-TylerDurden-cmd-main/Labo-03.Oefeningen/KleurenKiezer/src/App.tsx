import React, { useState } from "react";

const ColorPicker = () =>{
  const [color, SetColor] = useState("#000000");

  return (

    <React.Fragment>
      <input type="color" value={color} onChange={((e)=>SetColor(e.target.value))}/>
      <div style={{backgroundColor : color, width: 50, height: 50}} >

      </div>

      <select value={color} onChange={((e)=>SetColor(e.target.value))}>
        <option value="#000000">#000000</option>
        <option value="#FF0000">#FF0000</option>
        <option value="#00FF00">#00FF00</option>
        <option value="#0000FF">#0000FF</option>
      </select>
    </React.Fragment>
  )


}



const App = () =>{

  return (
    <React.Fragment>
      <ColorPicker/>
    </React.Fragment>
  )
}

export default App;