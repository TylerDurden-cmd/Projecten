import React, { useState } from "react";

const Counter = () =>{

/*     interface Colors{
        name:string
    } */
    let ColorSwitch:string = "";

    const [count,Setcount] = useState(0)

    const countIncrease = () =>{Setcount(count => count +1)};

    const countDecrease = () =>{Setcount(count => count -1)};

/*     const GreenText = () => {return (
        <>
        <div style={{color: "green"}}>
            counter: {count}
        </div>
        </>
    )}

    const RedTekst = (prop:Colors) =>{
        return(
            prop.name
        )
    } */
/* 
    const CountChecker = (prop:Colors) =>{
        if(count < 0){
            return prop.Red();
        }else{
            return prop.Green();
        }
    } */

    const CountChecker = () =>{
        if(count < 0){
            ColorSwitch = "red"
        }else if(count > 0){
            ColorSwitch = "green"
        }else[
            ColorSwitch = "lightgrey"
        ]
    }

    CountChecker();

    return(
        <React.Fragment>
            <body style={{display:"flex", gap: 20}}>
            <button onClick={countIncrease} value={count}>Omhoog</button>

            {/* {count < 0 ? ColorSwitch = 'red' : ColorSwitch = 'Green' } */}

            <div style={{color: ColorSwitch}}>Counter: {count} </div>

            <button onClick={countDecrease} value={count}>Omlaag</button>
            </body>
        </React.Fragment>
    )
}

const App = () =>{
    return (
        <React.Fragment>
            <Counter/>
            <Counter/>
            <Counter/>
        </React.Fragment>
    )
};

export default App;