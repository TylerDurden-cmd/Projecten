import React from "react";
import {useState} from "react";

const RandomCage = () =>{

  const [leftPosition, Setleft] = useState<number>(0);
  const [topPosition, Settop] = useState<number>(0);

  const RandomPosition =() =>{
    Setleft(leftPosition => leftPosition = Math.random() * 300)
    Settop(topPosition => topPosition = Math.random() * 300)
  }

  return (
    <>
    <img src="https://media.tenor.com/5iiD6jOOCuAAAAAC/quby-high-five.gif" style={{position: "fixed", top: topPosition, left: leftPosition, width:50, height: 50 }} />
    <button onClick={RandomPosition}>Random Cage</button>
    </>
  )
}

const App = () =>{
  return (
    <React.Fragment>
      <RandomCage/>
    </React.Fragment>
  )
}

export default App;
