import React, { useState } from "react";

const Checkbox = () => {

  const [Checked, SetChecked] = useState<boolean>(false)


  return (
    <React.Fragment>
      <input type="checkbox" onChange={((e)=>SetChecked(e.target.checked))}/>Show/Hide
      {Checked && <div style={{backgroundImage: "url('https://media.tenor.com/yheo1GGu3FwAAAAM/rick-roll-rick-ashley.gif')", height: 250, width: 200}}></div> }
    </React.Fragment>
  )
};




const App = () => {
  return (
    <React.Fragment>
      <Checkbox/>
    </React.Fragment>
  )
};

export default App;