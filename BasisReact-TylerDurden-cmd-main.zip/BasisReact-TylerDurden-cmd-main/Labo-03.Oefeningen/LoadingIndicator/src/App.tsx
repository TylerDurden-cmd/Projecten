import React, { useState } from "react";

const Loading = () =>{
    
    const [loading, SetLoading] = useState(false)

    const LoadFunc = () =>{SetLoading(true)}
    return (
        <React.Fragment>
            <button onClick={LoadFunc}>
                {loading && "loading" }
            </button>
        </React.Fragment>
    )
}


const App = () =>{

    return (
        <React.Fragment>
       <Loading/>     
        </React.Fragment>
    )

};

export default App;