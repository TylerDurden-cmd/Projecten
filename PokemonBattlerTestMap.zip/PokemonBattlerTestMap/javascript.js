import express from "express";
import cookieParser from "cookie-parser";
const app = express();

app.set("port", 3000);
app.set("view engine", "ejs");
app.use(express.static('public'));
app.use(cookieParser());
app.get("/", (req, res) => {
    res.render("index")
})

app.get("/Cookie", (req, res) => {
    res.cookie('Cookie', 'koekje')
    res.cookie('Cookie2', 'koekje')
    res.render("index")
})

app.get("/Cookie-get", (req, res) => {
    res.send(req.cookies.Cookie)
    res.render("index")
})

app.listen(app.get("port"), () => {
    console.log("Welkom Joachim [PichuPartners.] http://localhost:" + app.get("port"))
})

/* const func = async () => {
    const url = ("https://pokeapi.co/api/v2/pokemon-form/42/".slice(39, 42));
    console.log(url)
}
func(); */