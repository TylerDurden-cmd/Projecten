﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class Student : Person
    {


        public Student(string name, DateTime birthdate) : base(name, birthdate) { }

        /*private List<CourseRegistration> courseRegistrations = new List<CourseRegistration>();*/

  /*      public static List<Student> allStudents = new List<Student>();*/

        public static ImmutableList<Student> AllStudents
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<Student>();
                foreach(var item in AllPerson)
                {
                    if (item is Student)
                    {
                        builder.Add((Student)item);
                    }
                }
                return builder.ToImmutableList<Student>(); 
            }
        }

        public ImmutableList<CourseRegistration> CourseRegistrations
        {
            get 
                {
                var builder = ImmutableList.CreateBuilder<CourseRegistration>();
                List<string> courseList = new List<string>();
                foreach (var item in CourseRegistration.AllCourseRegistrations)
                {
                    if (item.Student.Id.Equals(this.Id) && !(courseList.Contains(item.Course.Title)))
                    {
                        courseList.Add(item.Course.Title);
                        builder.Add((CourseRegistration)item);
                    }
                }
                return builder.ToImmutableList<CourseRegistration>(); 
            }
        }

        public ImmutableList<Course> Courses
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<Course>();
                foreach(var item in CourseRegistrations)
                {
                    builder.Add(item.Course);
                }
                return builder.ToImmutableList<Course>();
            }
        }



        public Dictionary<DateTime,string> studentFile = new Dictionary<DateTime, string>();
    
        public ImmutableDictionary<DateTime,string> StudentFile
        {
            get { return studentFile.ToImmutableDictionary<DateTime, string>(); }
        }

        public override string GenerateNameCard()
        {
            return $"{this.Name} (STUDENT)";
        }

        public override double DetermineWorkload()
        {
            double NumberOfCourses = (double)this.CourseRegistrations.Count;
            return (double)(NumberOfCourses * 10);
        }

        public void RegisterCourseResult(Course course, byte? result)
        {
            
            if(!(result > 20))
            {
                CourseRegistration dummyCourseResult = new CourseRegistration(course,result,this);

            }
            else
            {
                Console.WriteLine("Ongeldige Cijfer");
            }
        }

        public double Average()
        {
            double total = 0;
            int counter = 0;
            foreach(var list in CourseRegistrations)
            {
                if(!(list.Result == null))
                {
                    total += (byte)list.Result;
                    counter++;
                }
                
            }

            return total / counter;
        }

        public void Showoverview()
        {
            Console.WriteLine($"{this.Name} ({Age} jaar)");
            Console.WriteLine("");
            Console.WriteLine($"Werkbelasting: {this.DetermineWorkload()} uren");
            Console.WriteLine("Cijferrapport:");
            Console.WriteLine("*************");
            foreach(var course in CourseRegistrations)
            {
                Console.WriteLine($"{course.Course.Title}:  {course.Result}");
            }
            
            Console.WriteLine($"Gemiddelde: {Math.Round(this.Average(),1)}");
        }

        public override string ToString()
        {
            return $"{base.ToString()}\nStudent";
        }

    }

    

}
