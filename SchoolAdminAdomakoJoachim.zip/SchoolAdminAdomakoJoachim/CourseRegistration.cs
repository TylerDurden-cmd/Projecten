﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class CourseRegistration
    {
		public CourseRegistration(Course? course, byte? result, Student? student)
		{
			this.Course = course;
			this.Result = result;
			this.student = student;
			try
			{
				foreach(var item in Course.AllCourses) 
				{
                    if (item.Id == course.Id)
                    {
                        if (student is null || course is null)
                        {
                            throw new ArgumentException();
                        }

                    }
                }
				if(AllCourseRegistrations.Count >= 1) 
				{
                    foreach (var item in AllCourseRegistrations)
                    {
                        try
                        {
                            if (item.Student.Name == student.Name && item.Course.Title == course.Title)
                            {
                                throw new ArgumentException();
                            }
                            int counter = 0;
                            foreach (var item2 in AllCourseRegistrations)
                            {
                                if (item2.Course.Id == course.Id)
                                {
                                    counter++;
                                }
                            }
                            try
                            {
                                if (counter > 20)
                                {
                                    throw new CapacityExceededException("Er zijn teveel studenten ingeschreven voor deze cursus");
                                }
                                allCourseRegistrations.Add(this);
                            }
                            catch (CapacityExceededException e)
                            {
                                Console.WriteLine("Er zijn teveel studenten ingeschreven voor deze cursus");
                            }
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine("Een student kan niet meermaals inschrijven voor dezelfde cursus");
                        }
                    }
                }
                else
                {
                    allCourseRegistrations.Add(this);
                }
				
            }
			catch (ArgumentException e)
			{
				Console.WriteLine("Student/cursus mag niet ontbreken.");
			}

            
        }
			


		private static List<CourseRegistration> allCourseRegistrations = new List<CourseRegistration>();

		public static ImmutableList<CourseRegistration> AllCourseRegistrations
		{
			get { return allCourseRegistrations.ToImmutableList<CourseRegistration>(); }
		}

		private Student student;
		public Student Student
		{
			get { return student; }
			private set 
			{ 
				student = value; 
			}
		}

		private Course course;

		public Course Course
		{
			get { return course; }
			private set { course = value; }
		}



		private byte? result;

		public byte? Result
		{
			get { return result; }
			set {

				if(!(result > 20))
				{
                    result = value;
                }
			}
		}

	}
}
