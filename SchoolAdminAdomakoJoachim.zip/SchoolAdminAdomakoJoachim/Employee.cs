﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal abstract class Employee : Person
    {
        public Employee(string name, DateTime birthDate, Dictionary<string,byte> tasks) : base(name, birthDate)
        {
            this.tasks = tasks;
        }

        private byte seniority;

        public byte Seniority
        {
            get { return seniority; }
            set 
            { 
                if(value > 50)
                {
                    value = 50;
                }
                seniority = value; 
            }
        }


        public static List<Employee> allEmployee = new List<Employee>();
        public static ImmutableList<Employee> AllEmployee
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<Employee>();
                foreach (var item in AllPerson)
                {
                    if(item is Employee)
                    {
                        builder.Add((Employee)item);
                    }
                }
                return builder.ToImmutableList<Employee>(); 
            }
        }

        public Dictionary<string,byte> tasks = new Dictionary<string, byte>();

        public ImmutableDictionary<string,byte> Tasks
        {
            get { return tasks.ToImmutableDictionary<string, byte>(); }
            
        }


        public override double DetermineWorkload()
        {
            throw new NotImplementedException();
        }

        public override string GenerateNameCard()
        {
            throw new NotImplementedException();
        }

        public abstract uint CalculateSalary();
    }
}
