﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class Lecturer : Employee
    {
        public Lecturer(string name, DateTime birthDate, Dictionary<string, byte> tasks) : base(name, birthDate, tasks){}


        private static List<Lecturer> allLecturer = new List<Lecturer>();
        public static ImmutableList<Lecturer> AllLecturer
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<Lecturer>();
                foreach(var item in AllPerson)
                {
                    if(item is Lecturer)
                    {
                        builder.Add((Lecturer)item);
                    }
                }
                return  builder.ToImmutableList<Lecturer>(); 
            }
            
        }

        private Dictionary<Course,double> courses;
            
        public Dictionary<Course,double> Courses
        {
            get { return courses; }
            set { courses = value; }
        }


        public override uint CalculateSalary()
        {

            double basis = 2200 + ((Seniority / 2) * 120);
            double workfee = (DetermineWorkload() / 40);
            return (uint)(basis * workfee); 
        }

        public override double DetermineWorkload()
        {

            double total = 0;
            foreach(var course in courses)
            {
                total += course.Value;
            }
            return total;
        }

        public override string GenerateNameCard()
        {
            string zin = "";
            foreach (var teskt in Courses)
            {
                zin += $"{teskt.Key.Title}\n";
            }
            return $"{Name}\nLector voor:\n{zin}";
        }

        public override string ToString()
        {
            return $"{base.ToString()}\nLecturer";
        }
    }
}
