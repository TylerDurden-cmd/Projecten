﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class StudyProgram
    {

		public StudyProgram(string name)
		{
			this.name = name;
		}

		private string name;

		public string Name
		{
			get { return name; }
		}

		public Dictionary<List<Course>,byte> courses = new Dictionary<List<Course>,byte>();

		public ImmutableDictionary<List<Course>,byte> Courses
		{
			get { return courses.ToImmutableDictionary<List<Course>, byte>(); }
		}

		public void ShowOverview()
		{
			Console.WriteLine($"{Name}");
			foreach(var semester in Courses.Values)
			{
				Console.WriteLine($"Semester{semester}:");
				if(Courses.Keys is null)
				{
					Console.WriteLine($"Er zijn geen cursussen in semester {semester}");
				}
                foreach (var item in Courses.Keys)
                {
					foreach(var i in item) { 
                    Console.WriteLine($"{i.Title} ({i.Id}) ({i.CreditPoints}stp)");
                    Console.WriteLine("");
                    }
                }
            }
		}

	}
}
