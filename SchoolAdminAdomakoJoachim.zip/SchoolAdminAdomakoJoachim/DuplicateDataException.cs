﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class DuplicateDataException: ApplicationException 
    {
        public DuplicateDataException(Object Object1, Object Object2,string message) :base(message)
        {
            this.Object1 = Object1;
            this.Object2 = Object2;
            
        }

        private System.Object object1;

        public System.Object Object1
        {
            get { return object1; }
            set { object1 = value; }
        }

        private System.Object object2;

        public System.Object Object2
        {
            get { return object2; }
            set { object2 = value; }
        }
    }
}
