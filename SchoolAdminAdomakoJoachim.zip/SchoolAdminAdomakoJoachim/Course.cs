﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class Course
    {
        public Course(string title, byte creditPoints)
        {
            this.Title = title;
            this.CreditPoints = creditPoints;
            try
            {
                foreach (var item in AllCourses)
                {

                    if (item.Title == this.Title)
                    {
                        throw new DuplicateDataException(this, item, "Nieuwe cursus heeft dezelfde naam als een bestaande cursus");
                    }


                }
                MaxId++;
                allCourses.Add(this);
            }
            catch (DuplicateDataException e)
            {
                Console.WriteLine($"{e.Message}");
                Console.WriteLine($"Id van de reeds bestaande cursus is: {this.Id}");
            }


        }

        public Course(string title) : this(title, 3){}

        private List<CourseRegistration> courseRegistrations = new List<CourseRegistration>();

        public ImmutableList<CourseRegistration> CourseRegistrations
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<CourseRegistration>();
                foreach (var item in CourseRegistration.AllCourseRegistrations)
                {
                    if (item.Course.Id.Equals(this.Id))
                    {
                        builder.Add((CourseRegistration)item);
                    }
                }
                return builder.ToImmutableList<CourseRegistration>();
            }
        }


        public string Title;
        public ImmutableList<Student> Students
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<Student>();
                foreach(var item in CourseRegistrations)
                {
                    if (item.Course.Id.Equals(this.Id))
                    {
                        builder.Add(item.Student);
                    }
                }
                return builder.ToImmutableList<Student>(); 
            }
        }


        private byte creditPoints;

        public byte CreditPoints
        {
            get { return creditPoints; }
            set { creditPoints = value; }
        }

        private int id;

        public int Id
        {
            get 
            {
                id = maxId;
                return id; 
            }
        }

        private int maxId;

        private int MaxId
        {
            get { return maxId; }
            set { maxId = 1; }
        }


        public static List<Course> allCourses = new List<Course>();

        public static ImmutableList<Course> AllCourses 
        {
            get { return allCourses.ToImmutableList<Course>(); }
        }


        public void ShowOverView()
        {
            Console.WriteLine($"{this.Title} ({this.Id}) ({this.CreditPoints}stp)");
            foreach(var student in this.Students)
            {
                Console.WriteLine($"{student.Name}");
            }
            Console.WriteLine("");
        }

        public Course SearchCourseById(int id)
        {

            foreach(var course in AllCourses)
            {
                if(course.Id == id)
                {
                    return course;
                }
                
            }

            return null;
        }

        public virtual bool Equals(Object o)
        {
            bool trueOrFalls;
            if (o is null && o is not Course)
            {
                trueOrFalls = false;
            }
            else
            {
                Course course = (Course)o;
                if (course.Id == this.Id)
                {
                    trueOrFalls = true;
                }
                else
                {
                    trueOrFalls = false;
                }
            }

            return trueOrFalls;




        }
    }
}
