﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal class AdministrativePersonnel : Employee
    {
        public AdministrativePersonnel(string name, DateTime birthDate, Dictionary<string, byte> tasks) : base(name, birthDate, tasks) {}

        public static ImmutableList<AdministrativePersonnel> AllAdministrativePersonnel
        {
            get 
            {
                var builder = ImmutableList.CreateBuilder<AdministrativePersonnel>();
                foreach(var item in AllPerson)
                {
                    if(item is AdministrativePersonnel)
                    {
                        builder.Add((AdministrativePersonnel)item);
                    }
                }
                return builder.ToImmutableList<AdministrativePersonnel>();
            }
        }


        public override uint CalculateSalary()
        {
            double basis = 2000 + ((Seniority / 3)  * 75);
            double workfee = DetermineWorkload() / 40;
            return (uint)(basis * workfee);
        }

        public override double DetermineWorkload()
        {
            double total = 0;
            foreach(var task in Tasks)
            {
                total += (double)task.Value;
            }
            return total;
        }

        public override string GenerateNameCard()
        {
            return $"{Name} (ADMINISTRATIE)";
        }

        public override string ToString()
        {

            return $"{base.ToString()}\nAdministratief personeel";

        }
    }
}
