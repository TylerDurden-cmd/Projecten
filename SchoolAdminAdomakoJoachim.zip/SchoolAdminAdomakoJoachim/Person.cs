﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Dynamic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdminExamenHerlhaling
{
    internal abstract class Person
    {

		public Person(string name, DateTime birthDate)
		{
			this.Name = name;
			this.birthDate = birthDate;
			maxId++;

			allPerson.Add(this);
		}

		private uint id;

		public uint Id
		{
			get 
			{
				id = maxId;
				return id; 
			}
		}

		private uint maxId;

		private uint Maxid
		{
			get { return maxId; }
			set { maxId = 1; }
		}

		private DateTime birthDate = new DateTime();

		public DateTime BirthDate
		{
			get { return birthDate; }
		}

		private int age;

		public int Age
		{
			get
			{
				age = DateTime.Now.Year - birthDate.Year ;
				if(DateTime.Now.Month > birthDate.Month && DateTime.Now.Day > birthDate.Day)
				{
					age = age - 1;
				}
				return age;
			}
		}
		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		public static List<Person> allPerson = new List<Person>();

		public static ImmutableList<Person> AllPerson
		{
			get { return allPerson.ToImmutableList<Person>(); }
		}

		public abstract double DetermineWorkload();

		public abstract string GenerateNameCard();

		public override bool Equals(Object o)
		{
			bool trueOrFalls;
			if(o is null && o is not Person)
			{
				trueOrFalls = false;
			}
			else
			{
				Person person = (Person)o;
				if(person.Id == this.Id)
				{
					trueOrFalls = true;
				}
				else
				{
					trueOrFalls = false;
				}
			}

			return trueOrFalls;


			
			
		}

		public override string ToString()
		{

			return $"Persoon\n-------\nNaam: {this.Name}\nLeeftijd: {this.Age}";
		}





	}
}
