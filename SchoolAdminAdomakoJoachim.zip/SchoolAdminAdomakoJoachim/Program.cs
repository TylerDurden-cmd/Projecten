﻿using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;

//We zitten nu aan hoofdstuk 13_1, H12 SchoolAdmin, al het voorig is gedaan

namespace SchoolAdminExamenHerlhaling
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            while (true) { 
            Console.WriteLine("Wat wil je doen?");
            Console.WriteLine("1.DemonstreerStudenten uitvoeren");
            Console.WriteLine("2.DemonstreerCursussen uitvoeren");
            Console.WriteLine("3.DemonstreerCSVFormat uitvoeren");
            Console.WriteLine("4.DemonstreerStudyProgramma uitvoeren");
            Console.WriteLine("5.DemonstreerAdministratiePersoneel uitvoeren");
            Console.WriteLine("6.DemonstreerLecturers uitvoeren");
            Console.WriteLine("7.Student toevoegen");
            Console.WriteLine("8.cursus toevoegen");
            Console.WriteLine("9.VakInschijvingen toevoegen");
            Console.WriteLine("10.inschrijvingsgegevens tonen");

            int inputGebruiker = Convert.ToInt32(Console.ReadLine());
            switch (inputGebruiker)
            {
                case 1:
                    DemoStudents();
                    break;
                case 2:
                    DemoCourses();
                    break;
                case 3:
                    ReadTextFormatStudent();
                    break;
                case 4:
                    DemoStudyProgram();
                    break;
                case 5:
                    DemoAdministrativePersonnel();
                    break;
                case 6:
                    DemoLecturers();
                    break;
                    case 7:
                        AddStudent();
                        break;
                    case 8:
                        AddCourse();
                        break;
                    case 9:
                        AddCourseRegistration();
                        break;
                    case 10:
                        ShowCourseRegistrations();
                        break;
                default:
                    Console.WriteLine("verkeerde input");
                    break;
            }
            }

        }

        public static void DemoCourses()
        {
            Student Said = new Student("Said Aziz", new DateTime(2000, 06, 01));


            Student Mieke = new Student("Mieke Vermeulen", new DateTime(1998, 01, 01));


            Course Programmeren = new Course("Programmeren");

            Course Databanken = new Course("Databanken");
            Databanken.Students.Add(Mieke);

            Course Communicatie = new Course("Communicatie");


            Course Webtechnologie = new Course("Webtechnologie");
            Webtechnologie.Students.Add(Mieke);

            Said.RegisterCourseResult(Programmeren, 15);
            Said.RegisterCourseResult(Databanken, 15);
            Said.RegisterCourseResult(Databanken, 14);
            Said.RegisterCourseResult(Communicatie, 1);

            Programmeren.ShowOverView();
            Databanken.ShowOverView();
            Communicatie.ShowOverView();
            Webtechnologie.ShowOverView();


        }

        public static void DemoStudents()
        {
            Student Said = new Student("Said Aziz", new DateTime(2000, 06, 01));

            Course Programmeren = new Course("Programmeren");
            Course Databanken = new Course("Databanken");
            Course Communicatie = new Course("Communicatie");
            Course Webtechnologie = new Course("Webtechnologie");

            Said.RegisterCourseResult(Programmeren, 14);
            Said.RegisterCourseResult(Programmeren, null);
            Said.RegisterCourseResult(Databanken, 15);
            Said.RegisterCourseResult(Webtechnologie, 13);
            Said.RegisterCourseResult(Communicatie, 12);


            Student Mieke = new Student("Mieke Vermeulen", new DateTime(1998, 01, 01));

            Mieke.RegisterCourseResult(Communicatie,13);
            Mieke.RegisterCourseResult(Programmeren,16);
            Mieke.RegisterCourseResult(Databanken,14);

            Said.Showoverview();
            Console.WriteLine("");
            Mieke.Showoverview();

        }

        public static void ReadTextFormatStudent()
        {
            Console.WriteLine("Geef de tekstvoorstelling van 1 student in CSV-formaat:");
            string inputGebruiker = Console.ReadLine();
            Console.WriteLine("");

            string[] tekstVoorstelling = inputGebruiker.Split(";");

            

            Student student = new Student(tekstVoorstelling[0], new DateTime(Convert.ToInt32(tekstVoorstelling[3]), Convert.ToInt32(tekstVoorstelling[2]), Convert.ToInt32(tekstVoorstelling[1])));
            for(int i = 4; i < tekstVoorstelling.Length; i+=2)
            {
                Course course =new Course(null);
                student.RegisterCourseResult(new Course(null).SearchCourseById(Convert.ToInt32(tekstVoorstelling[i])),Convert.ToByte(tekstVoorstelling[i + 1])) ;
            }

            student.Showoverview();

        }

        public static void DemoStudyProgram()
        {
            Course communicatie = new Course("Communicatie");
            Course programmeren = new Course("Programmeren");
            Course databanken = new Course("Databanken");
            List<Course> coursesProgrammeren = new List<Course>() { communicatie, programmeren, databanken };
            List<Course> coursesSNB = new List<Course>() { communicatie, programmeren, databanken };
            StudyProgram programmerenProgram = new StudyProgram("Programmeren");
            StudyProgram snbProgram = new StudyProgram("Systeem- en netwerkbeheer");
            programmerenProgram.courses.Add(coursesProgrammeren,1);
            snbProgram.courses.Add(coursesSNB, 2);
            programmerenProgram.ShowOverview();
            snbProgram.ShowOverview();

            
        }

        public static void DemoAdministrativePersonnel()
        {
            Dictionary<string, byte> taken = new Dictionary<string, byte>();
            taken.Add("roostering", 10);
            taken.Add("correspondentie", 10);
            taken.Add("animatie", 10);
            Student student = new Student("Joachim Adomako",new DateTime(2003,10,09));
            AdministrativePersonnel ahmed = new AdministrativePersonnel("Ahmed Azzoui",new DateTime(1998,04,02),taken);
            ahmed.Seniority = 4;

            foreach(var personeel in AdministrativePersonnel.AllAdministrativePersonnel)
            {
                Console.WriteLine(personeel.GenerateNameCard());
                Console.WriteLine(personeel.CalculateSalary());
                Console.WriteLine(personeel.DetermineWorkload());
            }
        }

        public static void DemoLecturers()
        {
            Dictionary<string, byte> taken = new Dictionary<string, byte>();
            taken.Add("roostering", 10);
            taken.Add("correspondentie", 10);
            taken.Add("animatie", 10);
            Lecturer anna = new Lecturer("anna Bolzano", new DateTime(1975, 06, 12), taken);
            Dictionary<Course, double> courses = new Dictionary<Course, double>();
            Course communicatie = new Course("Communicatie");
            Course programmeren = new Course("Programmeren");
            Course databanken = new Course("Databanken");
            courses.Add(communicatie, 3);
            courses.Add(programmeren, 3);
            courses.Add(databanken, 4);
            anna.Courses = courses;
            anna.Seniority = 9;


            foreach (var lecturer in Lecturer.AllLecturer)
            {
                Console.WriteLine(lecturer.GenerateNameCard());
                Console.WriteLine(lecturer.CalculateSalary());
                Console.WriteLine(lecturer.DetermineWorkload());
            }
        }

        public static void AddStudent()
        {
            Console.WriteLine("Naam van de student?");
            string name = Console.ReadLine();
            Console.WriteLine("Geboortedatum van de student?");
            DateTime dateTime = Convert.ToDateTime(Console.ReadLine());

            Student student = new Student(name, dateTime);
        }

        public static void AddCourse()
        {
            Console.WriteLine("Titel van de cursus?");
            string title = Console.ReadLine();
            Console.WriteLine("Aantal studiepunten?");
            byte credit = Convert.ToByte(Console.ReadLine());

            Course course = new Course(title, credit);
        }

        public static void AddCourseRegistration()
        {
            int result = 0;
            Console.WriteLine("Welke student?");
            Console.WriteLine("0.null");
            foreach(var item in Student.AllStudents)
            {
                Console.WriteLine($"{item.Id}:{item.Name}");
            }
            int inputStudent = Convert.ToInt32(Console.ReadLine());
            Student student = new Student("",new DateTime());
            foreach (var item in Student.AllStudents)
            {
                if(inputStudent == 0)
                {
                    student = null;
                }
                if(item.Id == inputStudent)
                {
                    student.Name = item.Name;
                }   
            }
            Console.WriteLine("Welke cursus?");
            Console.WriteLine("0.null");
            foreach (var item in Course.AllCourses)
            {
                Console.WriteLine($"{item.Id}:{item.Title}");
            }
            int inputCursus = Convert.ToInt32(Console.ReadLine());
            Course course = new Course("");
            foreach (var item in Course.AllCourses)
            {
                if(inputCursus == 0)
                {
                    course = null;
                }
                if (item.Id.Equals(inputCursus))
                {
                    course.Title = item.Title;
                    course.CreditPoints = item.CreditPoints;
                }
            }

            Console.WriteLine("Wil je een resultaat toekennen?");
            string antwoord = Console.ReadLine().ToLower();
            if(antwoord == "ja")
            {
                Console.WriteLine("Wat is het resultaat?");
                result = Convert.ToInt32(Console.ReadLine());
            }
                CourseRegistration registration = new CourseRegistration(course,(byte)result,student);
        }

        public static void ShowCourseRegistrations()
        {
            foreach(var item in CourseRegistration.AllCourseRegistrations)
            {
                Console.WriteLine($"{item.Student.Name} ingeschreven voor {item.Course.Title}");
            }
        }



    }
}